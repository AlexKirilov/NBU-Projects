
import java.util.Random;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Axel
 */

//Raboteshtata nishka trqbva da sveti v cherveno
//Nishkite da budat prespivani za random interval ot vreme m/u (1000 - 2000)ms
public class ThreadCreate {
    //private String sName;
    //private long lTimeInterval;
    int buffer; //Buffer za kritichen resurs;
    boolean valueSet = false; //Flag - za postavena li e stoinost v buffer-a
    Random randtime = new Random();
    int time = randtime.nextInt(2000) + 1000;
    //Poluchavane na stoinost ot buffera
    synchronized int get () {
        if (!valueSet)
            try{
               wait (); // Izchakva se postavqneto na stoinost v buffer-a 
            }
        catch(InterruptedException e) {}; 
       
        valueSet = false;
        notify (); //Buffer-ut e pro4eten - deblokirame nishkata Pisatel
        return buffer;
    }
    // Поставяне на стойност в буфера
	synchronized void put(int n) {
	   if (valueSet)
	   	 try {
	   	 	//System.out.println ("Waiting for putting! n = " + n);
                        Thread.sleep(time);
	   	 	wait();  // Чакаме прочитане на стойността от буфера и деблокиране на нишката "писател"
	   }
	   catch(InterruptedException e) {};
	   buffer = n;
	   valueSet = true;
	   System.out.println("Put: " + n);
	   notify();  // Стойността е в буфера - деблокираме нишката "Читател"
	} 
}
class Producer implements Runnable { 
	ThreadCreate tc;
	Producer(ThreadCreate tc) { 
		this.tc = tc;
		new Thread(this, "Producer").start();
                //Pispivane na nishkite
                
	}

	public void run() {  // Прави опит да запише 20 стойности в буфера
		//for (int i = 0; i < 20; i++) { 
		//	tc.put((int) (Math.random() *10));
		} 
	} 



class Consumer implements Runnable { 
	ThreadCreate tc;
	Consumer(ThreadCreate tc) {
		this.tc = tc;
		new Thread(this, "Consumer").start();
	}

	public void run() {  // Постоянно опитва да чете от буфера
		while (true) {
			tc.get();
		}
	}
}
   
